# version info
module Soracom
  VERSION = '1.1.7'
end
