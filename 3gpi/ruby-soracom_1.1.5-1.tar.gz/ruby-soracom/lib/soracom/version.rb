# version info
module Soracom
  VERSION = '1.1.5'
end
