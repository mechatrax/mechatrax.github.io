#ruby-soracom  

ruby-soracom は SORACOM SDK for Ruby を gem2deb で debian パッケージ化したものです。  

ruby-soracom パッケージには SORACOM SDK for Ruby で提供される SDK と CLI が含まれます。  
また、soracom コマンドの bash_completion が追加されます。  

SORACOM SDK for Ruby の詳細は下記リンク先のドキュメントをご覧ください。  
https://github.com/soracom/soracom-sdk-ruby  
