# version info
module Soracom
  VERSION = '1.1.6'
end
