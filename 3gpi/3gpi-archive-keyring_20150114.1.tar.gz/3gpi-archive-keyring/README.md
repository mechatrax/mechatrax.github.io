# 3gpi-archive-keyring
3GPIのリポジトリの署名を提供します。

## 提供ファイル
以下のファイルがパッケージに含まれています。

* /usr/share/doc/3gpi-archive-keyring/changelog.gz  
  パッケージの変更点を記録したファイルです。

* /usr/share/doc/3gpi-archive-keyring/copyright  
  パッケージ内のファイルの著作権を記述したファイルです。

* /usr/share/keyrings/3gpi-archive-keyring.gpg  
  3GPIのリポジトリの公開鍵です。
