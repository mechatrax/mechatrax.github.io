# version info
module Soracom
  VERSION = '1.1.4'
end
