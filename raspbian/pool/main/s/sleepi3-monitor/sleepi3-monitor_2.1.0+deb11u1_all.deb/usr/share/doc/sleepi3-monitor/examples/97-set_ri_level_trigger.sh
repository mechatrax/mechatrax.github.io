#!/bin/bash

sleepi3ctl set ri-trigger 1

