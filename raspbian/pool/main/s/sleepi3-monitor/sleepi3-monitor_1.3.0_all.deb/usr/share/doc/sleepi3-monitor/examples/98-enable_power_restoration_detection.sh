#!/bin/bash

sleepi3ctl set measurement-interval 10
sleepi3ctl set restore-voltage 10000
