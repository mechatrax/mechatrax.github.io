# sleepi-archive-keyring
slee-Pi のリポジトリの署名を提供します。

## 提供ファイル
以下のファイルがパッケージに含まれています。

* /usr/share/doc/sleepi-archive-keyring/changelog.gz  
  パッケージの変更点を記録したファイルです。

* /usr/share/doc/sleepi-archive-keyring/copyright  
  パッケージ内のファイルの著作権を記述したファイルです。

* /usr/share/keyrings/sleepi-archive-keyring.gpg  
  slee-Pi のリポジトリの公開鍵です。
